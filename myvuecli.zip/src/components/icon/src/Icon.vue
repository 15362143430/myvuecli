<template>
    <i :class='"l-icon-"+name'></i>
</template>

<script>
export default {
    props:{
        name:String
    }
}
</script>

<style lang="less" scoped>

</style>