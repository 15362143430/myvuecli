<template>
  <div class="l-button-group">
      <slot></slot>
  </div>
</template>

<script>
export default {
  
};
</script>

<style lang='less' scoped>
@import '../../../asset/styles/components/button/ButtonGroup.less';
</style>